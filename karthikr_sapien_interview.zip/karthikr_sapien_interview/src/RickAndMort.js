import React from 'react';
import './RickMort.css';

export default class RickMort extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            RickMortJSON : {},
            FilteredJson: {}
        }
        this.filteredItems = [];
    }
    componentDidMount() {
        let localInstance = this;
        fetch("https://rickandmortyapi.com/api/character/").then((res)=>{
            return res.json();
        }).then((response) => {
            localInstance.setState({
                FilteredJson : response.results,
                RickMortJSON: response.results
            })
        })
    }

    getOrigin = (text) => {
        let origin = (text.indexOf(" ") !== -1) ? text.slice(0, text.indexOf(" ")): text;
        return origin;
    }
    updateData = (e) => {
        if(this.filteredItems.indexOf(e.target.parentElement.innerText.toLowerCase()) === -1 && e.target.checked) {
            this.filteredItems.push(e.target.parentElement.innerText.toLowerCase());
        }
        if (!e.target.checked && this.filteredItems.indexOf(e.target.parentElement.innerText.toLowerCase()) >-1 ) {
            this.filteredItems.splice(this.filteredItems.indexOf(e.target.parentElement.innerText.toLowerCase()) , 1);
        }
        let tempJson = [];
        this.state.RickMortJSON.map((item, index) => {
            if(this.filteredItems.indexOf(item.species.toLowerCase()) > -1 && this.filteredItems.indexOf('male') === -1 && this.filteredItems.indexOf('female') === -1) {
                tempJson.push(item);
            } 
        })
        if (tempJson.length === 0) {
            tempJson = this.state.RickMortJSON;
        }
        this.setState({
            FilteredJson: tempJson
        })
    }
    render() {
        if(Object.keys(this.state.FilteredJson).length > 0) {
        return(
            <React.Fragment>
             <div className="control_panels">
               <div className="filter_section">
                    <p>Species</p>
                    <div className="species">
                        <label htmlFor="human"><input type="checkbox" name="human" id="human" onChange={this.updateData.bind(this)} />human</label><br />
                        <label htmlFor="Alien"><input type="checkbox" name="Alien" id="Alien" onChange={this.updateData.bind(this)}/>Alien</label>
                    </div>
                </div>
            </div>
            <div className="wrapper">
                 {
                     this.state.FilteredJson.map((item, index) => {
                        return <div className="rockmort_details">
                        <img src={item.image} className="rockmort_img"></img>
                        <div className="shadow"></div>
                        <div className="avatar_name">
                            <span className="name">
                                <p>{item.name}</p>
                     <p>id: {item.id} - Created 2 years ago</p>
                            </span>
                        </div>
                        <div className="detail status">
                            <span className="title">Status</span>
                            <span className="value">{item.status}</span>
                        </div>
                        <div className="detail species">
                            <span className="title">Species</span>
                            <span className="value">{item.species}</span>
                        </div>
                        <div className="detail gender">
                            <span className="title">Gender</span>
                            <span className="value">{item.gender}</span>
                        </div>
                        <div className="detail origin">
                            <span className="title">Origin</span>
                            <span className="value">{this.getOrigin(item.origin.name)}</span>
                        </div>
                        <div className="detail location">
                            <span className="title">Location</span>
                            <span className="value">{this.getOrigin(item.origin.name)}</span>
                        </div>
                    </div>
                    })
                }
            </div>
            </React.Fragment>
        )
    } else {
        return <div>
            <div className="control_panels">
                <div className="filter_section">
                        <p>Species</p>
                        <div className="species">
                            <label htmlFor="human"><input type="checkbox" name="human" id="human" onChange={this.updateData.bind(this)} />human</label><br />
                            <label htmlFor="Alien"><input type="checkbox" name="Alien" id="Alien" onChange={this.updateData.bind(this)}/>Alien</label>
                        </div>
                    </div>
                </div>
                <h3>No items found</h3>
        </div>
    }
    }
}