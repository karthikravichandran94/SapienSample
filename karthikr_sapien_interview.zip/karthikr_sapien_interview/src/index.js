import React from 'react';
import ReactDOM from 'react-dom';
import RickMort from './RickAndMort';
import './index.css';

ReactDOM.render(
  <RickMort />,
  document.getElementById('root')
);
